---
title: Outerlies_in_Quantization 
tags: ppt
preview_previewType: presentation
---

# Outerlies in Quantization

----

### How to Understand Outliers

1. ##### Resolution V.S. Range
2. ##### Clipping 
![Weights histogram](./images/1571256901927.png)


----

### Split the Value

Inspired from `Net2Net` [1]

![Net2Net widens one layer by copying neurons. After splitting, the map function of this layer is totally the same as before.](./images/1571257386709.png)

[1] Chen, T., Goodfellow, I., and Shlens, J. Net2net: Accelerating Learning via Knowledge Transfer. Int’l Conf. on Learning Representations (ICLR), May 2016.

----


#### Use `Net2Net` to Split Weights/Activation


![Activation Splitting and Weights Spliting](./images/1571257685018.png)


----


#### But, Quantization Function is NOT Linear



$Q(w) \neq Q(\frac12 w) + Q(\frac12 w)$

So, naive splitting 

![Naive Splitting](./images/1571258283665.png)
will introduce extra quantization error.

----

#### Quantization-Aware Splitting

![](./images/1571258683904.png)

The last line is simply $Q(w)$, showing that QA OCS pre- serves the original quantization result.

----

To derive the last line, we apply `Hermite’s Identity` with n = 2

![ =300x](./images/1571258817748.png)

----

#### Split What?

As stated earlier, OCS **cannot** target individual weights or activations and must duplicate entire channels.

![ =800x](./images/1571259073349.png)

##### Future Work
1. Select Channels with a fashion way like RL.

----

### Hardware Solution

----

#### Second Processing Engine

[1, 2] proposed an outlier-aware DNN accelerator (OLAccel) which uses a conventional pro- cessing engine (PE) for central activations and a second sparse PE for outliers. 



```
Park, E., Kim, D., and Yoo, S. Energy-Efficient Neural Net- work Accelerator Based on Outlier-Aware Low-Precision Computation.ISCA, 2018
Park, E., Yoo, S., and Vajda, P. Value-aware Quantization for Training and Inference of Neural Networks. arXiv:1804.07802, 2018
```

----

![](./images/1571270231553.png)

----

OLAccel achieves < 1% accuracy loss on AlexNet using 4 bits for most values and 16 bits for a small percentage of outliers. Though effective, OLAccel’s
major drawback is using an entirely separate outlier engine — this requires additional multiply-accumulate (MAC) units and incurs hardware overheads due to sparsity.

----

#### Opportunistical Rewriting

![High-level Idea](./images/1571270451642.png)

When this overwrite occurs, $x_i$ is represented using twice the normal bitwidth while $x_{i+1}$ is dropped.

----

![](./images/1571284208892.png)

----

![](./images/1571284290200.png)

----

##### Channel Reordering
OverQ is predicated on the
fact that outliers will be adjacent to a small value with high probability. We can increase this probability by reordering the channels in a layer such that channels likely to contain outliers are adjacent to channels likely to contain zeros.

----

1. activation distributions are sampled using a small profiling dataset
2. the number of outliers in each channel are counted
3. the channels are reordered by the outlier count following a sequence of `high`, `low`, `high`, `low`, `high`, etc.

----

##### Hardware Implementation

![](./images/1571284601419.png)

----

#### Prevent Outliers with BP

1. Forward
![](./images/1571328007736.png)![](./images/1571328196837.png )![](./images/1571328130540.png)

2. Backward
![](./images/1571328398567.png)

> This gradient is the weighted average of all weight gradients in the filter, except the gradient of the element with maximum absolute value itself. 

----


> This gradient will make the element with maximum absolute value move towards zero in each iteration, which can ultimately avoid (eliminate) the long-tail of the weight distribution after many iterations.

##### Why?

----

![](./images/1571330173197.png)